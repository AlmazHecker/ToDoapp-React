//I won't even import React because I'm not going to write any JSX code in there.

const Wrapper = props => {
    //I technically still only returned one thing,
    return props.children;
}

export default Wrapper;
